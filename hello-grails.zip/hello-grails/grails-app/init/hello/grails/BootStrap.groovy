package hello.grails

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
